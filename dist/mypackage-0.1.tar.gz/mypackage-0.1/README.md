# mypackage
# This library was created for test purposes as an example of hw to publish python packages
# building the package locally
 'python setup.py sdist'
# how to install
